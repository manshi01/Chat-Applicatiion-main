# Chat-Applicatiion
It is an scalable Realtime Chatting Application that provides an interface for multiple user chatting at the same time. We can easily chat with our group of friends by broadcasting the messages on the group . This application is just made for fun activities and we can add more functionalises to this simple application to make it a complex application like WhatsApp. Hence this is just a prototype of how a broadcasting application works .

----------------------------------------------------------Process to run the app----------------------------------------------------------------------

1 -run nodemon nodeserver/index.js

2 -Install the extension 'live server' for Vs Code. Extension Id - ritwickdey.liveserver

3- After the extension gets installed navigate to index.html and open it to edit.

4-Right click anywhere in the file index.html and from the menu that appears select Open with Live server

5-A instance of the application will appear in the browser.

6-Copy the url from the address bar and open another instance in another tab or in incognito or on another browser
